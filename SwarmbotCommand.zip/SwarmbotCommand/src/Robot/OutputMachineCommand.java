package Robot;

public class OutputMachineCommand {
    private String command;
    public OutputMachineCommand(String command){
        this.command=command;
    }
    public void acknolwedge(){
        System.out.println(command);
    }
}
