package Robot;

public class Robot {
    int x;
    int y;
    int z;
    int h;
    int d;
    RobotParameter state;
    RobotParameter camera;
    RobotParameter function;
    RobotParameter base;

    public Robot() {
    }

    public Robot(int x, int y, int z, int h, int d) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.h = h;
        this.d = d;
    }

    public void setX(int input) {
        this.x = input;
    }

    public void setY(int input) {
        this.y = input;
    }

    public void setZ(int input) {
        this.z = input;
    }

    public void setH(int input) {
        this.h = input;
    }



    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getZ() {
        return z;
    }

    public int getH() {
        return h;
    }

}
