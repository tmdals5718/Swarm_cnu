package Simulation;

import Robot.Robot;
import User.InputUserCommand;

import java.util.HashMap;
import java.util.Map;

public class Start {
    public Start() {
    }

    public static void main(String args[]) {
        InputUserCommand initiate = new InputUserCommand();
        System.out.println("Ready to initiated. Input commands.");
        while(true) {
            initiate.inputCommand();
        }

    }

}
