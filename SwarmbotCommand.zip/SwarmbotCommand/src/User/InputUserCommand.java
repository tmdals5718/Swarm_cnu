package User;

import Robot.OutputMachineCommand;

import java.util.Scanner;

public class InputUserCommand {
    OutputMachineCommand robot;
    public InputUserCommand() {
    }

    private String userCmd;

    public void inputCommand() {
        Scanner scan = new Scanner(System.in);
        TranslateCommand translate = new TranslateCommand();
        userCmd = scan.nextLine();
        while (userCmd.length() > 0) {
            try {
                userCmd = translate.receiveCommand(userCmd);
            } catch (Exception e) {
                System.out.println("▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒\nUnexpected Error Occurs.\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒\n");
            }
            robot = new OutputMachineCommand(translate.getCommandLine());
            robot.acknolwedge();
        }

    }
}

